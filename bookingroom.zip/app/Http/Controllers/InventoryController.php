<?php

namespace App\Http\Controllers;

use App\Models\InventoryItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class InventoryController extends Controller
{
    use AuthorizesRequests;

    public function index()
    {
        $inventoryItems = InventoryItem::orderBy('name')->get();
        return view('inventories.index', compact('inventoryItems'));
    }

    public function create()
    {
        $this->authorize('create', InventoryItem::class);
        return view('inventories.create');
    }

    public function store(Request $request)
    {
        $this->authorize('create', InventoryItem::class);

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:inventory_items,name',
            'photo' => 'nullable|image|max:2048',
            'total_stock' => 'required|integer|min:0',
            'available_stock' => 'required|integer|min:0',
            'damaged_stock' => 'required|integer|min:0',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $path = $request->file('photo')?->store('inventory_photos', 'public');

        InventoryItem::create([
            'name' => $request->name,
            'photo' => $path,
            'total_stock' => $request->total_stock,
            'available_stock' => $request->available_stock,
            'damaged_stock' => $request->damaged_stock,
        ]);

        return redirect()->route('inventories.index')->with('success', 'Item berhasil ditambahkan');
    }

    public function show(InventoryItem $inventory)
    {
        $units = $inventory->units()->get();
        $this->authorize('view', $inventory);
        return view('inventories.show', compact('inventory', 'units'));
    }

    public function edit(InventoryItem $inventory)
    {
        $this->authorize('update', $inventory);
        return view('inventories.edit', compact('inventory'));
    }

    public function update(Request $request, InventoryItem $inventory)
    {
        $this->authorize('update', $inventory);

        $validator = Validator::make($request->all(), [
            'name' => ['required', Rule::unique('inventory_items')->ignore($inventory->id)],
            'photo' => 'nullable|image|max:2048',
            'total_stock' => 'required|integer|min:0',
            'available_stock' => 'required|integer|min:0',
            'damaged_stock' => 'required|integer|min:0',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $data = $request->only(['name', 'total_stock', 'available_stock', 'damaged_stock']);

        if ($request->hasFile('photo')) {
            Storage::disk('public')->delete($inventory->photo);
            $data['photo'] = $request->file('photo')->store('inventory_photos', 'public');
        }

        $inventory->update($data);

        return redirect()->route('inventories.index')->with('success', 'Item berhasil diperbarui');
    }

    public function destroy(InventoryItem $inventory)
    {
        $this->authorize('delete', $inventory);

        Storage::disk('public')->delete($inventory->photo);
        $inventory->delete();

        return redirect()->route('inventories.index')->with('success', 'Item berhasil dihapus');
    }
}
