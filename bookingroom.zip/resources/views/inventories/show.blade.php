<x-app-layout>
    <style>
        /* ========================================
   UNIT DETAIL PAGE STYLES
======================================== */

        .unit-detail-container {
            padding: 3rem 1rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .unit-detail-card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 4px 20px -4px rgba(30, 41, 59, 0.08);
            padding: 2rem;
            animation: fadeIn 0.4s ease-out;
        }

        /* Header Section */
        .unit-detail-header {
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
        }

        .unit-detail-title {
            font-size: 1.875rem;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
        }

        /* Unit Section Header */
        .unit-section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 2px solid #e2e8f0;
            padding-top: 1.5rem;
            margin-bottom: 1.5rem;
            gap: 1rem;
        }

        .unit-section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }

        .unit-count-badge {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }

        .btn-add-unit {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, #6366f1, #4f46e5);
            color: white;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
        }

        .btn-add-unit:hover {
            background: linear-gradient(135deg, #4f46e5, #4338ca);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4);
        }

        /* Table Styles */
        .unit-table-container {
            overflow-x: auto;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
        }

        .unit-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 700px;
        }

        .unit-table thead {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
        }

        .unit-table th {
            padding: 1rem;
            text-align: left;
            font-size: 0.75rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 2px solid #e2e8f0;
        }

        .unit-table th.text-center {
            text-align: center;
        }

        .unit-table td {
            padding: 1rem;
            font-size: 0.875rem;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }

        .unit-table tbody tr {
            transition: all 0.2s ease;
        }

        .unit-table tbody tr:hover {
            background-color: #f8fafc;
        }

        /* Unit Photo */
        .unit-photo {
            width: 48px;
            height: 48px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border: 2px solid #e2e8f0;
        }

        .unit-photo-placeholder {
            width: 48px;
            height: 48px;
            background: #f1f5f9;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #94a3b8;
            font-size: 0.75rem;
            font-weight: 500;
        }

        /* Serial Number */
        .serial-number {
            font-weight: 600;
            color: #1e293b;
            font-family: 'Courier New', monospace;
        }

        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.375rem 0.875rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .status-available {
            background: linear-gradient(135deg, #dcfce7, #bbf7d0);
            color: #166534;
            border: 1px solid #86efac;
        }

        .status-in-use {
            background: linear-gradient(135deg, #fef9c3, #fef08a);
            color: #854d0e;
            border: 1px solid #fde047;
        }

        .status-damaged,
        .status-maintenance {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b;
            border: 1px solid #fca5a5;
        }

        /* Holder */
        .unit-holder {
            color: #64748b;
        }

        .unit-holder-gudang {
            color: #22c55e;
            font-weight: 600;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 0.375rem 0.75rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            border: none;
            cursor: pointer;
        }

        .btn-detail {
            background: #e0e7ff;
            color: #4338ca;
        }

        .btn-detail:hover {
            background: #c7d2fe;
        }

        .btn-edit {
            background: #dbeafe;
            color: #1d4ed8;
        }

        .btn-edit:hover {
            background: #bfdbfe;
        }

        .btn-delete {
            background: #fee2e2;
            color: #dc2626;
        }

        .btn-delete:hover {
            background: #fecaca;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #94a3b8;
        }

        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .empty-state-text {
            font-size: 1rem;
            color: #64748b;
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* ========================================
   RESPONSIVE STYLES
======================================== */

        @media (max-width: 768px) {
            .unit-detail-container {
                padding: 1.5rem 0.75rem;
            }

            .unit-detail-card {
                padding: 1.25rem;
                border-radius: 12px;
            }

            .unit-detail-title {
                font-size: 1.5rem;
            }

            .unit-section-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }

            .unit-section-title {
                font-size: 1.25rem;
            }

            .btn-add-unit {
                width: 100%;
                justify-content: center;
                padding: 0.875rem 1rem;
            }

            .unit-table th,
            .unit-table td {
                padding: 0.75rem 0.5rem;
                font-size: 0.75rem;
            }

            .unit-photo {
                width: 40px;
                height: 40px;
            }

            .action-buttons {
                flex-direction: column;
                gap: 0.375rem;
            }

            .btn-action {
                width: 100%;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .unit-detail-title {
                font-size: 1.25rem;
            }

            .unit-section-title {
                font-size: 1.125rem;
            }

            .unit-count-badge {
                font-size: 0.75rem;
            }
        }
    </style>
    <div class="unit-detail-container">
        <div class="unit-detail-card">

            <div class="unit-detail-header">
                <h2 class="unit-detail-title">{{ $inventory->name }}</h2>
            </div>

            <div class="unit-section-header">
                <h3 class="unit-section-title">
                    Unit Detail <span class="unit-count-badge">{{ $units->count() }} Unit</span>
                </h3>
                <a href="{{ route('inventories.units.create', $inventory->id) }}" class="btn-add-unit">
                    + Tambah Unit Satuan
                </a>
            </div>

            <div class="unit-table-container">
                <table class="unit-table">
                    <thead>
                        <tr>
                            <th>Foto</th>
                            <th>Nomor Serial</th>
                            <th>Status</th>
                            <th>Pemegang</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($units as $unit)
                        <tr>
                            <td>
                            @if ($unit->photo && file_exists(public_path('storage/'.$unit->photo)))
                            <img src="{{ secure_asset('storage/' . $unit->photo) }}"
                                class="w-full h-auto rounded-lg shadow border"
                                alt="Foto Unit">
                            @else
                            <div class="bg-gray-100 p-8 rounded text-center text-gray-500">
                                Tidak ada foto unit
                            </div>
                            @endif
                            <td><span class="serial-number">{{ $unit->serial_number ?? 'N/A' }}</span></td>
                            <td>
                                <span class="status-badge status-{{ $unit->condition_status }}">
                                    {{ ucfirst(str_replace('_', ' ', $unit->condition_status)) }}
                                </span>
                            </td>
                            <td>
                                <span class="{{ $unit->current_holder ? 'unit-holder' : 'unit-holder-gudang' }}">
                                    {{ $unit->current_holder ?? 'Gudang' }}
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="{{ route('inventories.units.show', [$inventory->id, $unit->id]) }}" class="btn-action btn-detail">Detail</a>
                                    <a href="{{ route('inventories.units.edit', [$inventory->id, $unit->id]) }}" class="btn-action btn-edit">Edit</a>
                                    @can('delete', $unit)
                                    <form action="{{ route('inventories.units.destroy', [$inventory->id, $unit->id]) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button class="bg-red-600 text-white px-4 py-2 rounded">
                                            Hapus Unit
                                        </button>
                                    </form>
                                    @endcan
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    <div class="empty-state-icon"></div>
                                    <p class="empty-state-text">Belum ada unit satuan yang terdaftar.</p>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</x-app-layout>
