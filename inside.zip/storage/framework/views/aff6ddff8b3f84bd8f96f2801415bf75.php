<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/inventory.css')); ?>">

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">

                <h2 class="text-2xl font-semibold text-gray-800 mb-2">
                    Detail Unit: <?php echo e($unit->serial_number ?? 'Unit #' . $unit->id); ?>

                </h2>

                <p class="text-gray-500 mb-6">
                    Bagian dari item:
                    <a href="<?php echo e(route('inventories.show', $inventory->id)); ?>"
                       class="text-indigo-600 hover:text-indigo-800 font-medium">
                        <?php echo e($inventory->name); ?>

                    </a>
                </p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                    
                        <div>
                        <p class="text-lg font-semibold text-gray-700 mb-2 border-b">Foto Unit</p>
                    
                        <?php if($unit->photo && file_exists(public_path($unit->photo))): ?>
                            <img
                                src="<?php echo e(asset($unit->photo)); ?>"
                                class="w-full h-auto rounded-lg shadow border"
                                alt="Foto Unit">
                        <?php else: ?>
                            <div class="bg-gray-100 p-8 rounded text-center text-gray-500">
                                Tidak ada foto unit
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div>
                        <p class="text-lg font-semibold text-gray-700 mb-2 border-b">Informasi Unit</p>

                        <div class="mb-4">
                            <p class="text-sm text-gray-500">Nomor Serial</p>
                            <p class="font-bold"><?php echo e($unit->serial_number ?? 'N/A'); ?></p>
                        </div>

                        <div class="mb-4">
                            <p class="text-sm text-gray-500">Status</p>
                            <span class="px-3 py-1 rounded-full text-sm font-semibold
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'bg-green-100 text-green-800' => $unit->condition_status === 'available',
                                    'bg-yellow-100 text-yellow-800' => $unit->condition_status === 'in_use',
                                    'bg-red-100 text-red-800' => in_array($unit->condition_status, ['damaged','maintenance']),
                                ]); ?>"">
                                <?php echo e(ucfirst(str_replace('_', ' ', $unit->condition_status))); ?>

                            </span>
                        </div>

                        <div class="mb-4">
                            <p class="text-sm text-gray-500">Pemegang</p>
                            <p><?php echo e($unit->current_holder ?? 'Gudang'); ?></p>
                        </div>

                        <div class="mb-4">
                            <p class="text-sm text-gray-500">Dibuat</p>
                            <p><?php echo e($unit->created_at->format('d M Y H:i')); ?></p>
                        </div>
                    </div>
                </div>

                
                <div class="flex flex-wrap gap-3 mt-8 pt-4 border-t">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $unit)): ?>
                        <a href="<?php echo e(route('inventories.units.edit', [$inventory->id, $unit->id])); ?>"
                           class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Edit Unit
                        </a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $unit)): ?>
                        <form action="<?php echo e(route('inventories.units.destroy', [$inventory->id, $unit->id])); ?>"
                              method="POST"
                              onsubmit="return confirm('Yakin ingin menghapus unit ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                Hapus Unit
                            </button>
                        </form>
                    <?php endif; ?>

                    <a href="<?php echo e(route('inventories.show', $inventory->id)); ?>"
                       class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                        Kembali
                    </a>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\KAI\bookingroom\resources\views/inventory_units/show.blade.php ENDPATH**/ ?>