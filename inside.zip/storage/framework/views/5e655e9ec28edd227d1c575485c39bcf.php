<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/inventory.css')); ?>">

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">

                <h2 class="text-2xl font-semibold text-gray-800 mb-6">
                    Tambah Unit untuk: <strong><?php echo e($inventory->name); ?></strong>
                </h2>

                <form action="<?php echo e(route('inventories.units.store', $inventory->id)); ?>"
                      method="POST"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    
                    <?php if($errors->any()): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">
                            Scan Barcode (HP)
                        </label>

                        <div id="reader"
                             class="border rounded p-2 mb-2"
                             style="max-width:320px"></div>

                        <small class="text-gray-500">
                            Izinkan kamera, arahkan ke barcode
                        </small>
                    </div>

                    
                    <div class="mb-4">
                        <label for="serial_number"
                               class="block text-gray-700 text-sm font-bold mb-2">
                            Nomor Serial / Barcode
                        </label>

                        <input
                            type="text"
                            name="serial_number"
                            id="serial_number"
                            value="<?php echo e(old('serial_number')); ?>"
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            placeholder="Scan barcode atau ketik manual"
                        >
                    </div>

                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">
                            Foto Unit (Opsional)
                        </label>
                        <input type="file" name="photo" class="border rounded w-full p-2">
                    </div>

                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">
                            Status Kondisi
                        </label>
                        <select name="condition_status" required
                                class="border rounded w-full p-2">
                            <option value="available">Tersedia</option>
                            <option value="in_use">Sedang Dipakai</option>
                            <option value="maintenance">Perawatan</option>
                            <option value="damaged">Rusak</option>
                        </select>
                    </div>

                    
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2">
                            Pemegang Saat Ini (Opsional)
                        </label>
                        <input type="text" name="current_holder"
                               class="border rounded w-full p-2">
                    </div>

                    
                    <div class="flex justify-between">
                        <button type="submit"
                                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                            Simpan Unit
                        </button>

                        <a href="<?php echo e(route('inventories.show', $inventory->id)); ?>"
                           class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                            Batal
                        </a>
                    </div>
                </form>

            </div>
        </div>
    </div>

    
    <script src="https://unpkg.com/html5-qrcode"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const serialInput = document.getElementById('serial_number');
            const html5QrCode = new Html5Qrcode("reader");

            html5QrCode.start(
                { facingMode: "environment" }, // kamera belakang
                {
                    fps: 10,
                    qrbox: { width: 250, height: 250 }
                },
                (decodedText) => {
                    serialInput.value = decodedText;
                    html5QrCode.stop();
                },
                () => {}
            );
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\KAI\bookingroom\resources\views/inventory_units/create.blade.php ENDPATH**/ ?>